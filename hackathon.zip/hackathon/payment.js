// Payment links
const upiBase = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(agency)}&am=${amount}&cu=INR&tn=${note}`;

// Try Paytm first
document.getElementById("paytmBtn").onclick = () => {
  window.location.href = `paytm://upi/pay?${upiBase.replace("upi://pay?", "")}`;
};

// Try PhonePe first
document.getElementById("phonepeBtn").onclick = () => {
  window.location.href = `phonepe://pay?${upiBase.replace("upi://pay?", "")}`;
};

// Try Google Pay first
document.getElementById("gpayBtn").onclick = () => {
  window.location.href = `tez://upi/pay?${upiBase.replace("upi://pay?", "")}`;
};
